#include "Pokedex.h"
/*
class pokedex
{
	public:
		pokedex();
		~pokedex();
		void pListHelpgter();
		void addP();
		void displayP();
		void displayPType();

	private:
		pokemon pList[];
		int pListCap;
		int pListCount;
	
};

struct pokemon
{
	char name[NAME];
	char type[TYPE];
	char moves[MOVES];
	int candy;
	int hp;
};
*/
/*
list::list()
{
cout << "How many movies would you like: ";
cin >> size_of_array;
cin.ignore(100, '\n');
array = new movie[size_of_array];
num_of_movies = 0;

alternative:
array = NULL;
size_of_array = 0;
num_of_movies = 0;
}

//Destructor will deallocate the dynamic memory
list::~list()
{
if (NULL != array)
delete [] array;
array = 0;
size_of_array = 0;
num_of_movies = 0;
}
*/

pokedex::pokedex()
{

	pList  = nullptr;
	pListCount = 0;
	pListCap = 0;
}

pokedex::~pokedex()
{
	if(pList != nullptr)
	{
		delete [] pList;
		pList = 0;
		pListCap = 0;
		pListCount = 0;
	}
}

void pokedex::pListHelper()
{
	if(!pList)
	{
		cout << "How many Pokemon should your Pokedex hold?: ";
		cin >> pListCap;
		cin.ignore(100,'\n');

		while(pListCap <= 0)
		{
			cout << "Please enter a positive number" << endl;
			cout << "How many pokemon should your Pokedex hold: ";

			cin >> pListCap;
			cin.ignore(100,'\n');
		}
		
		pList = new pokemon[pListCap];

	}

}

void pokedex::addP()
{

}

void pokedex::displayP()
{

}
